let miArray = [1,2,3,4];

let aleatorio;
function desordenar(miArray){

    
   
    
  miArray.reverse(miArray);





}
alert(desordenar(miArray))

let trocear = "Protocolo://subdominio.dominio.extension/subcarpeta/subcarpeta/recurso.extension";

function troceo(){
    let urlTroceado = trocear.split("/");
    
    alert(urlTroceado);
}
troceo();

let suUrl = prompt("Escriba una url");

function principal(){

    
}